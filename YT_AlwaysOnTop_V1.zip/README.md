# 📺 YT AlwaysOnTop

> **Truly edgeless, Always-on-Top Picture-in-Picture for YouTube. Work while you watch!**

![YT AlwaysOnTop Logo](icon.png)

YT AlwaysOnTop is a minimalist Chrome extension designed for maximum productivity. It transforms the standard YouTube experience into a floating, borderless window that stays on top of all other applications.

---

### ⭐ Star the Repo!
If you find this extension useful, please consider giving it a **Star**! It helps more people discover the project.

---

## ✨ Features

- **🚀 Truly Edgeless**: No title bars, no borders, no distractions. Just your video.
- **📌 Always on Top**: Stays pinned above all other windows (Browsers, IDEs, Slack, etc.).
- **🔄 Auto-Launch**: Automatically pops the video out when you switch tabs or start a new video.
- **⚡ Hotkey Support**: Toggle the mode instantly with `Alt + P`.
- **🎨 Native UI**: Injected button blends perfectly with YouTube's official player controls.
- **🔒 Quality Lock**: Automatically maintains high-definition playback in floating mode.

## 🛠️ Installation

### Chrome Web Store (Recommended)
*Coming soon!*

### Developer Mode (Manual)
1. Download this repository as a ZIP and extract it.
2. Open Chrome and go to `chrome://extensions/`.
3. Enable **Developer mode** (top right toggle).
4. Click **Load unpacked** and select the folder you extracted.

## ⌨️ Shortcuts

| Action | Shortcut |
| :--- | :--- |
| **Toggle PiP** | `Alt + P` |

## 🤝 Contributing
Contributions, issues, and feature requests are welcome!

## 📜 License
MIT License. Free for personal and commercial use.

---

*Handcrafted with ❤️ for the YouTube community.*
